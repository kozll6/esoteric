# Quantum Superposition Delay - Quick Start Guide

## What You Have

Complete source code for a VCV Rack plugin that implements the Quantum Superposition Delay algorithm - a unique multi-buffer probabilistic delay effect.

## Files Included

```
QuantumDelay/
├── README.md                           # Full user documentation
├── BUILD.md                            # Build instructions
├── COMPARISON.md                       # Hardware vs VCV comparison
├── LICENSE                             # MIT License
├── Makefile                           # Build configuration
├── plugin.json                        # Plugin metadata
├── src/
│   ├── plugin.hpp                     # Plugin header
│   ├── plugin.cpp                     # Plugin initialization
│   └── QuantumSuperpositionDelay.cpp  # Main module (all DSP code)
└── res/
    └── QuantumSuperpositionDelay.svg  # Panel design
```

## Quick Start (5 Minutes)

### Prerequisites
1. Download VCV Rack SDK: https://vcvrack.com/downloads/
2. Install build tools (see BUILD.md for details)

### Build & Install

```bash
# 1. Extract to your Rack SDK plugins folder
cd /path/to/Rack-SDK/plugins/
unzip QuantumDelay.zip  # (or git clone, or copy folder)

# 2. Set Rack SDK path
export RACK_DIR=/path/to/Rack-SDK

# 3. Build
cd QuantumDelay
make

# 4. Install
make install

# 5. Launch VCV Rack and search for "Quantum"
```

## Key Features

✅ **6 independent delay buffers** (up to 2 seconds total)
✅ **Probabilistic mixing** - buffers blend based on evolving probability weights
✅ **Quantum collapse** - trigger input causes dramatic redistribution
✅ **Entanglement** - buffers influence each other through feedback
✅ **Visual feedback** - LEDs show buffer activity
✅ **Full CV control** - all parameters voltage controllable

## First Patch

```
1. Add "Quantum Superposition Delay" module
2. Connect an oscillator or audio source to IN
3. Connect OUT to your audio interface or mixer
4. Turn TIME to ~50%
5. Turn MIX to ~50%
6. Play with PROB knob - hear the texture morph!
7. Patch a slow LFO to PROB CV input
8. Patch a clock to COLLAPSE trigger
```

## Core Algorithm

The module maintains 6 delay buffers simultaneously. Instead of mixing them equally, each buffer has a **probability weight** that determines its contribution. These weights evolve smoothly based on:

- **PROB**: Distribution shape (uniform ↔ peaked)
- **CHAOS**: Random perturbations
- **COLLAPSE**: Trigger events that redistribute weights
- **Entanglement**: Cross-buffer feedback influence

## Quick Patches

### Quantum Chorus
```
TIME: 20-50ms
SPREAD: 50%
PROB: 20%
FDBK: 20%
CHAOS: 10%
```
Result: Lush, shimmering chorus

### Rhythmic Evolution
```
TIME: 400ms
SPREAD: 80%
PROB: 70%
FDBK: 50%
COLLAPSE: Patched to clock
```
Result: Evolving rhythmic delays

### Granular Clouds
```
TIME: 100ms
SPREAD: 60%
PROB: 50%
CHAOS: 80%
FDBK: 50%
```
Result: Textural soundscapes

## Documentation

- **README.md**: Complete user manual with all features
- **BUILD.md**: Detailed build instructions for all platforms
- **COMPARISON.md**: Hardware vs VCV Rack comparison
- **Source code**: Heavily commented for learning

## Customization

Want more/fewer buffers? Edit `src/QuantumSuperpositionDelay.cpp`:

```cpp
static constexpr int NUM_BUFFERS = 6;  // Change this!
```

Want longer delays?

```cpp
static constexpr int MAX_DELAY_SAMPLES = 96000;  // Increase this!
```

Then rebuild with `make clean && make && make install`

## Learning Resources

The code is extensively commented and designed to be readable. Key sections:

1. **Buffer allocation**: Line ~35
2. **Probability weight calculation**: `updateProbabilityWeights()` function
3. **Audio processing**: `process()` function  
4. **Quantum collapse**: `handleQuantumCollapse()` function
5. **Entanglement**: Within the buffer read loop

## Troubleshooting

**Module doesn't appear in VCV Rack:**
- Check that plugin.json exists
- Verify files are in correct plugins directory
- Check VCV Rack log.txt for errors

**Build errors:**
- Make sure RACK_DIR is set correctly
- Check SDK version (need v2.0+)
- See BUILD.md for platform-specific fixes

**Crackling/artifacts:**
- Reduce CHAOS amount
- Lower FEEDBACK value
- Check CPU usage isn't maxed out

## Next Steps

1. ✅ Build and install the module
2. 📖 Read README.md for full documentation
3. 🎵 Try the example patches
4. 🔧 Experiment with customizing the code
5. 🌐 Share your patches with the VCV community!

## Support

- VCV Rack Forums: https://community.vcvrack.com/
- VCV Rack Manual: https://vcvrack.com/manual/
- Plugin Development: https://vcvrack.com/manual/PluginDevelopmentTutorial

## From Hardware to Software

This VCV Rack module is a direct port of the Teensy 4.0 hardware Eurorack module. The DSP algorithm is **identical** - same delay buffers, same probability calculations, same quantum collapse behavior.

Key differences:
- Higher audio quality (32-bit vs 12-bit)
- Visual LED feedback included
- Easier to experiment and modify
- Free vs $50 hardware build

See COMPARISON.md for detailed comparison.

---

**Ready to explore quantum superposition in your patches!**

The module implements the full algorithm with:
- ✅ 6-buffer delay system
- ✅ Probabilistic mixing
- ✅ Smooth weight morphing  
- ✅ Quantum collapse events
- ✅ Delay line entanglement
- ✅ Chaos control

**Enjoy!**
