# Quantum Superposition Delay - VCV Rack Module

A VCV Rack port of the hardware Eurorack Quantum Superposition Delay module. This unique delay effect creates evolving, probabilistic textures using multiple delay buffers in "quantum superposition."

## Overview

Unlike traditional delays that route audio through a single buffer, the Quantum Superposition Delay maintains **6 independent delay buffers simultaneously**. Each buffer contributes to the output based on probability weights that morph and evolve in response to control voltages, creating organic, unpredictable soundscapes.

### Key Features

- **6 independent delay buffers** with up to 2 seconds total delay time
- **Probabilistic mixing** - each buffer has a probability weight determining its contribution
- **Smooth weight morphing** - probability distribution evolves gradually
- **Quantum collapse events** - trigger input causes dramatic probability redistribution
- **Delay line entanglement** - feedback from one buffer influences others
- **Chaos control** - adds randomness to probability updates
- **Visual feedback** - 6 LEDs show buffer activity, collapse indicator

## Installation

### From Source

1. Clone or download this repository into your Rack plugins folder:
   ```bash
   cd <Rack SDK>/plugins/
   git clone <repository> QuantumDelay
   cd QuantumDelay
   ```

2. Compile the plugin:
   ```bash
   make
   ```

3. Install to your plugins directory:
   ```bash
   make install
   ```

4. Restart VCV Rack

### Pre-compiled Binary

1. Download the latest release from [releases page]
2. Extract to your Rack plugins folder
3. Restart VCV Rack

## Controls

### Parameters (Knobs)

| Control | Range | Function |
|---------|-------|----------|
| **TIME** | 0-2000ms | Base delay time for all buffers |
| **SPREAD** | 0-100% | Time spacing between buffers (0% = all equal, 100% = max spread) |
| **PROB** | 0-100% | Probability distribution shape (0% = uniform, 100% = peaked) |
| **FDBK** | 0-95% | Global feedback amount |
| **MIX** | 0-100% | Dry/wet balance |
| **CHAOS** | 0-100% | Randomness in probability updates |

### Inputs

| Input | Type | Function |
|-------|------|----------|
| **IN** | Audio | Audio input |
| **PROB** | CV (0-10V) | Modulates probability distribution |
| **SPREAD** | CV (0-10V) | Modulates time spread |
| **FDBK** | CV (0-10V) | Modulates feedback amount |
| **COLLAPSE** | Gate/Trigger | Triggers quantum collapse event |

### Outputs

| Output | Type | Function |
|--------|------|----------|
| **OUT** | Audio | Mixed audio output |

### Visual Indicators

- **COLLAPSE** (Red LED) - Lights when collapse event occurs
- **BUFFERS** (6 Blue LEDs) - Show relative probability weight of each buffer

## Usage Guide

### Patch Ideas

#### 1. Quantum Chorus
**Goal**: Lush, wide chorus effect

```
TIME: 20-50ms
SPREAD: 40-60%
PROB: 20% (more uniform)
FDBK: 20%
CHAOS: 10%
```

This creates a shimmering, chorus-like effect with subtle movement.

#### 2. Rhythmic Superposition
**Goal**: Evolving rhythmic delays

```
TIME: 300-800ms
SPREAD: 70-90%
PROB: 60-80% (more peaked)
FDBK: 40-60%
COLLAPSE: Patched to clock divider
```

The peaked probability emphasizes certain buffers, creating rhythmic patterns. Clock triggers at the collapse input create rhythmic shifts.

#### 3. Granular Clouds
**Goal**: Textural, granular soundscapes

```
TIME: 50-150ms
SPREAD: 60%
PROB: 50% (moderate)
CHAOS: 70-90%
FDBK: 50%
```

High chaos creates constantly shifting textures. Works great on pad sounds or field recordings.

#### 4. Entangled Feedback Network
**Goal**: Self-organizing, evolving feedback

```
TIME: 100-500ms
SPREAD: 50%
FDBK: 60-80%
PROB: Slow LFO (0.1-1 Hz)
CHAOS: 30%
```

Patch a slow LFO to PROB CV input. The buffers will continuously reorganize, with entanglement creating organic cross-pollination.

#### 5. Probability Morphing
**Goal**: Smooth textural evolution

```
TIME: 200-400ms
SPREAD: 50%
PROB: Envelope follower or slow sine LFO
FDBK: 40%
MIX: 60%
```

Use an envelope follower or slow LFO on PROB input to morph between uniform and peaked distributions based on input dynamics.

### CV Modulation Tips

- **PROB Distribution CV**: 
  - Slow LFO (0.1-1 Hz) for gradual morphing
  - Envelope follower for dynamic response
  - Random stepped voltage for unpredictable shifts

- **TIME SPREAD CV**:
  - Audio-rate modulation creates chorus/vibrato effects
  - Stepped random for rhythmic variation
  - Envelope for dynamic time changes

- **COLLAPSE Trigger**:
  - Clock for rhythmic reorganization
  - Random gates for sporadic changes
  - Manual trigger button for performance
  - End-of-phrase gates for musical structure

- **FEEDBACK CV**:
  - Use cautiously - high values can cause runaway feedback
  - Envelope follower for dynamic feedback based on input level
  - Inverted envelope for "ducking" feedback

### Advanced Techniques

#### Stereo Width from Mono
1. Create a second instance of the module
2. Set slightly different TIME and SPREAD values
3. Use different CHAOS amounts
4. Occasionally trigger COLLAPSE on only one side
5. Result: Wide, evolving stereo field from mono source

#### Self-Patching
1. Patch OUT back to IN (through mixer or attenuator)
2. Set MIX to 50-70%
3. Use FDBK sparingly (20-40%)
4. Creates complex, self-organizing feedback networks

#### Sidechain Probability Control
1. Patch envelope follower from different sound source to PROB CV
2. The probability distribution will respond to external rhythms
3. Great for creating reactive, interdependent patches

## Technical Details

### Algorithm Overview

The module maintains 6 delay buffers, each with:
- Independent delay time (distributed by SPREAD control)
- Probability weight (determines contribution to output)
- Feedback level
- Entanglement value (influences other buffers)

Each sample:
1. Input written to all buffers
2. Delayed samples read from each buffer
3. Each sample weighted by probability
4. Weighted samples summed
5. Feedback applied with entanglement cross-modulation
6. Dry/wet mixing
7. Output

Probability weights evolve using:
- Target weights calculated based on PROB shape
- Current weights smoothly interpolate toward targets
- Velocity-based smoothing prevents abrupt changes
- Chaos adds random perturbations

### Performance

- **CPU Usage**: Moderate (single-threaded DSP)
- **Memory**: ~6.4 MB for delay buffers
- **Latency**: Minimal (processing-only, no additional buffering)
- **Sample Rate**: Adapts to Rack engine sample rate

### Differences from Hardware

The VCV Rack version is largely identical to the Teensy hardware version, with these adaptations:

1. **Sample Rate**: Adapts to VCV Rack engine (typically 44.1-96kHz) instead of fixed 44.1kHz
2. **Voltage Ranges**: Uses VCV Rack standard (±5V audio, 0-10V CV) instead of Eurorack levels
3. **UI**: VCV Rack standard controls instead of physical pots/jacks
4. **Interpolation**: Added linear interpolation for smoother delay time modulation
5. **Visual Feedback**: Added LED indicators for buffer activity

Core DSP algorithm is identical to hardware.

## Troubleshooting

### No Output
- Check that input is connected
- Verify MIX is not at 0%
- Ensure TIME is not at minimum

### Crackling/Artifacts
- Reduce CHAOS amount
- Lower FDBK value
- Check for extreme modulation ranges on CV inputs

### Feedback Runaway
- Reduce FDBK parameter
- Lower FDBK CV input voltage
- Check entanglement isn't creating positive feedback loop

### CPU Spikes
- Disable module when not in use
- Reduce number of instances
- Consider freezing the output to audio

## Development

### Building from Source

Requirements:
- VCV Rack SDK (v2.0+)
- C++11 compatible compiler
- Make

```bash
export RACK_DIR=/path/to/Rack-SDK
cd QuantumDelay
make
make install
```

### Code Structure

```
QuantumDelay/
├── plugin.json          # Plugin metadata
├── Makefile            # Build configuration
├── src/
│   ├── plugin.hpp      # Plugin header
│   ├── plugin.cpp      # Plugin initialization
│   └── QuantumSuperpositionDelay.cpp  # Main module
└── res/
    └── QuantumSuperpositionDelay.svg  # Panel design
```

### Customization

To modify buffer count:
```cpp
static constexpr int NUM_BUFFERS = 6;  // Change this value
```

To modify maximum delay time:
```cpp
static constexpr int MAX_DELAY_SAMPLES = 96000;  // 2 seconds at 48kHz
```

Note: Increasing these values increases memory usage proportionally.

## Theory of Operation

### Quantum Superposition

In quantum mechanics, particles exist in multiple states simultaneously until measured. This module applies that concept to delay buffers:

- Each buffer represents a possible "quantum state"
- Probability weights determine likelihood of each state
- Output is weighted superposition of all states
- Collapse trigger "measures" the system, forcing it into a specific configuration

### Probability Distribution

The PROB parameter controls distribution shape:

- **Low values (0-50%)**: More uniform - all buffers contribute equally
- **High values (50-100%)**: Peaked - emphasizes certain buffers

The distribution evolves smoothly, with velocity-based interpolation preventing jarring transitions.

### Entanglement

When feedback from buffer A influences buffer B's content, they become "entangled." This creates complex interdependencies where the behavior of one buffer affects others, leading to emergent, organic behavior.

Entanglement strength is proportional to buffer energy (amplitude), so loud buffers have more influence.

### Chaos

Chaos adds random perturbations to probability weights, creating unpredictable evolution. Higher chaos values lead to more dramatic, rapid changes.

## License

MIT License - see LICENSE file for details

## Credits

- **Algorithm Design**: Based on quantum mechanics concepts and probabilistic systems
- **Hardware Version**: Teensy 4.0 Eurorack module
- **VCV Rack Port**: Adapted for VCV Rack ecosystem

## Version History

### v2.0.0 (Current)
- Initial VCV Rack port
- Full DSP algorithm implementation
- Visual feedback with LED indicators
- CV modulation on all parameters

## Support

For bug reports, feature requests, or questions:
- GitHub Issues: [link]
- VCV Community Forum: [link]

---

**Quantum Superposition Delay** - Where probability meets time
