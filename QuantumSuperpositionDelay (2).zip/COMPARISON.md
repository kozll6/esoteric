# Quantum Superposition Delay: Hardware vs. VCV Rack Comparison

## Overview

This document compares the Teensy 4.0 hardware Eurorack module with the VCV Rack software port, highlighting similarities, differences, and considerations for each platform.

## Core Algorithm - IDENTICAL

Both versions implement the same quantum superposition delay algorithm:

✅ 6 independent delay buffers
✅ Probabilistic mixing with weighted superposition  
✅ Smooth probability weight morphing
✅ Quantum collapse events
✅ Delay line entanglement
✅ Chaos/randomness control
✅ Velocity-based weight interpolation

**The DSP is mathematically identical between platforms.**

## Key Differences

### Audio Specifications

| Feature | Hardware (Teensy) | VCV Rack |
|---------|-------------------|----------|
| Sample Rate | Fixed 44.1 kHz | Adaptive (44.1-192 kHz) |
| Bit Depth | 12-bit DAC/ADC | 32-bit float |
| Audio Range | ±5V (Eurorack) | ±5V (VCV standard) |
| Dynamic Range | ~72 dB (12-bit) | >120 dB (float) |
| Noise Floor | ~-70 dB | < -100 dB |

**Winner: VCV Rack** (higher resolution, better noise performance)

### CV Input Range

| Feature | Hardware | VCV Rack |
|---------|----------|----------|
| Input Range | 0-5V (Eurorack) | 0-10V (VCV standard) |
| Protection | Schottky diodes | Software clamping |
| Resolution | 12-bit (4096 steps) | 32-bit float |

**Winner: VCV Rack** (higher resolution, wider voltage range)

### Control Response

| Feature | Hardware | VCV Rack |
|---------|----------|----------|
| Knob Resolution | 12-bit ADC | Continuous (float) |
| Control Update Rate | Every 5ms | Every 64 samples (~1.45ms @ 44.1kHz) |
| Latency | <1ms | <1ms |

**Winner: Tie** (both have excellent control response)

### Memory & Performance

| Feature | Hardware | VCV Rack |
|---------|----------|----------|
| RAM Available | 1 MB (Teensy 4.0) | System RAM |
| Buffer Size | 16,000 samples/buffer | 16,000 samples/buffer |
| Max Delay Time | 2 seconds total | 2 seconds total |
| CPU Usage | ~30% @ 600MHz | Moderate (depends on host) |
| Polyphony | Single | Single (multiply instances) |

**Winner: VCV Rack** (unlimited RAM, can run many instances)

### Visual Feedback

| Feature | Hardware | VCV Rack |
|---------|----------|----------|
| Buffer Activity | Not included (optional) | 6 LED indicators |
| Collapse Event | Not included (optional) | Red LED indicator |
| Panel Display | Physical knobs/jacks | Virtual UI |

**Winner: VCV Rack** (built-in visual feedback)

### Cost & Accessibility

| Feature | Hardware | VCV Rack |
|---------|----------|----------|
| Parts Cost | $45-60 USD | Free (software) |
| Build Time | 2-4 hours | 5 minutes (compile) |
| Tools Needed | Soldering, multimeter | Computer, SDK |
| Portability | Physical module | Save patches anywhere |
| No Computer Needed | ✅ Yes | ❌ No |

**Winner: Depends on use case**
- Hardware: Standalone, tactile, no computer required
- VCV: Free, instant, easy to experiment

## Feature Comparison Table

| Feature | Hardware | VCV Rack | Notes |
|---------|----------|----------|-------|
| **CONTROLS** | | | |
| Delay Time | ✅ | ✅ | Identical range |
| Spread | ✅ | ✅ | Identical behavior |
| Probability | ✅ | ✅ | Identical algorithm |
| Feedback | ✅ | ✅ | Identical range |
| Mix | ✅ | ✅ | Identical behavior |
| Chaos | ✅ | ✅ | Identical randomness |
| **CV INPUTS** | | | |
| Probability CV | ✅ 0-5V | ✅ 0-10V | VCV has wider range |
| Spread CV | ✅ 0-5V | ✅ 0-10V | VCV has wider range |
| Feedback CV | ✅ 0-5V | ✅ 0-10V | VCV has wider range |
| Collapse Trigger | ✅ Gate | ✅ Gate | Identical behavior |
| **AUDIO** | | | |
| Audio Input | ✅ Mono | ✅ Mono | Identical |
| Audio Output | ✅ Mono | ✅ Mono | Identical |
| Frequency Response | 20Hz-20kHz | 20Hz-96kHz | VCV higher due to SR |
| **INDICATORS** | | | |
| Buffer Activity | Optional | ✅ | VCV has built-in LEDs |
| Collapse Event | Optional | ✅ | VCV has indicator |
| **INTEGRATION** | | | |
| Power | Eurorack ±12V | Host computer | |
| MIDI Control | Not built-in | ✅ Via VCV MIDI modules | |
| Preset Storage | Not built-in | ✅ Patch files | |
| Automation | Via CV | ✅ Via CV + automation | |

## Use Case Recommendations

### Choose Hardware When:

✅ Building a hardware Eurorack system
✅ Want standalone operation (no computer)
✅ Prefer tactile, physical controls
✅ Performing live with modular hardware
✅ Learning electronics/embedded programming
✅ Want the satisfaction of building something
✅ Integrating with other Eurorack modules

### Choose VCV Rack When:

✅ Working in-the-box (DAW integration)
✅ Prototyping/experimenting before building hardware
✅ Want unlimited instances/polyphony
✅ Prefer visual feedback (LEDs)
✅ Need preset/patch recall
✅ Want to try before building hardware
✅ Teaching/learning about the algorithm
✅ Budget constraints (free software)

## Migration Path

### From VCV Rack to Hardware

If you develop patches in VCV Rack and want to build hardware:

1. ✅ Algorithm is identical - patches will sound the same
2. ✅ CV ranges compatible (0-5V subset of 0-10V)
3. ⚠️ VCV automations need to be recreated as CV modulation
4. ⚠️ Multiple instances become multiple hardware modules

### From Hardware to VCV Rack

If you have hardware and want to work in software:

1. ✅ Patches translate directly
2. ✅ Can save presets for instant recall
3. ✅ Can run multiple instances simultaneously
4. ✅ Higher audio quality
5. ⚠️ Requires computer for operation

## Performance Characteristics

### CPU Usage Comparison

**Hardware (Teensy 4.0 @ 600 MHz):**
- Processing: ~30% CPU
- Headroom: ~70% available
- Real-time guarantee: ✅ Yes (bare metal)

**VCV Rack (typical modern CPU):**
- Processing: ~5-10% of one core
- Multiple instances: Linear scaling
- Real-time guarantee: Depends on host CPU load

### Latency Comparison

**Hardware:**
- ADC latency: <0.1ms
- Processing: <0.5ms
- DAC latency: <0.1ms
- **Total: <1ms**

**VCV Rack:**
- Input: Depends on audio interface
- Processing: <1ms
- Output: Depends on audio interface
- **Total: Variable (typically 5-20ms including audio I/O)**

## Audio Quality Shootout

### Noise Floor
- Hardware: ~-70 dB (limited by 12-bit ADC/DAC)
- VCV Rack: < -100 dB (32-bit float)
- **Winner: VCV Rack**

### Aliasing/Artifacts
- Both use same anti-aliasing strategy
- Hardware: Limited by 44.1kHz SR
- VCV Rack: Better at higher sample rates
- **Winner: VCV Rack (at high SR)**

### Character/Warmth
- Hardware: Slight DAC/ADC non-linearity can add "analog" character
- VCV Rack: Mathematically perfect
- **Winner: Subjective** (some prefer hardware "coloration")

## Expandability

### Hardware
- ✅ Can add physical modifications (LEDs, switches)
- ✅ Can interface with other Eurorack modules
- ⚠️ Requires PCB redesign for major changes
- ⚠️ Limited by physical panel space

### VCV Rack
- ✅ Easy to modify code and recompile
- ✅ Can integrate with any VCV module
- ✅ Unlimited virtual expansion
- ✅ Easy to add new features via software

**Winner: VCV Rack** (easier to expand and modify)

## Reliability

### Hardware
- ✅ No OS crashes
- ✅ Boots instantly
- ✅ No software updates required
- ⚠️ Can fail due to component damage
- ⚠️ Environmental sensitivity (heat, moisture)

### VCV Rack
- ✅ No physical component failures
- ✅ Easy to backup/restore
- ⚠️ Depends on host OS stability
- ⚠️ Plugin updates may break compatibility

**Winner: Tie** (different failure modes)

## Recommendations by Scenario

### Scenario 1: Learning the Algorithm
**Recommendation: VCV Rack**
- Free, instant setup
- Visual feedback helps understanding
- Easy to experiment with parameters

### Scenario 2: Studio Production
**Recommendation: VCV Rack**
- DAW integration
- Preset recall
- Unlimited instances
- Automation

### Scenario 3: Live Performance (Electronic)
**Recommendation: Depends**
- With laptop: VCV Rack (flexibility)
- Without laptop: Hardware (reliability)

### Scenario 4: Eurorack Integration
**Recommendation: Hardware**
- Native Eurorack voltage levels
- Physical integration
- No computer required

### Scenario 5: Education/Teaching
**Recommendation: VCV Rack**
- Visual feedback aids learning
- Easy to demonstrate
- Students can experiment freely

### Scenario 6: DIY Learning Experience
**Recommendation: Hardware**
- Learn electronics
- Embedded programming
- Satisfaction of building

## Hybrid Approach

You can use both! Common workflows:

1. **Prototype in VCV, Build in Hardware**
   - Develop patches in VCV Rack
   - Perfect the sound
   - Build hardware for final performance

2. **Hardware for Live, VCV for Studio**
   - Use hardware in live rig
   - Use VCV Rack for studio production
   - Same sonic character in both

3. **VCV as Hardware Supplement**
   - Use VCV Rack when traveling
   - Hardware for main studio
   - Share patches between platforms

## Future-Proofing

### Hardware
- ✅ Will work indefinitely (if maintained)
- ⚠️ Can't easily update algorithm
- ⚠️ Limited by Teensy 4.0 specs

### VCV Rack
- ✅ Can update with new features
- ✅ Will improve with VCV Rack updates
- ⚠️ May require recompilation for new VCV versions

## Conclusion

**Both versions are excellent** and implement the same core algorithm faithfully.

Choose based on your workflow:
- **Hardware**: Standalone, tactile, Eurorack integration
- **VCV Rack**: Flexibility, experimentation, production

The best approach might be to start with VCV Rack to learn and experiment, then build hardware if you want to integrate with a Eurorack system or prefer standalone operation.

**The sound is the same - the choice is about workflow and context.**

---

*"Whether electrons flow through silicon or float in software, the quantum superposition remains."*
