# Building the Quantum Superposition Delay VCV Rack Module

## Prerequisites

### 1. Install VCV Rack SDK

Download the VCV Rack SDK for your platform:
- **Windows**: https://vcvrack.com/downloads/Rack-SDK-2.5.2-win-x64.zip
- **Mac**: https://vcvrack.com/downloads/Rack-SDK-2.5.2-mac-x64.zip
- **Linux**: https://vcvrack.com/downloads/Rack-SDK-2.5.2-lin-x64.zip

Extract to a convenient location, e.g., `~/Rack-SDK/`

### 2. Install Build Tools

**Windows:**
```bash
# Install MSYS2 from https://www.msys2.org/
# Then in MSYS2 terminal:
pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-make
```

**Mac:**
```bash
# Install Xcode Command Line Tools:
xcode-select --install
```

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get install build-essential git
```

## Building the Plugin

### Step 1: Clone/Download the Source

```bash
cd /path/to/Rack-SDK/plugins/
git clone <repository-url> QuantumDelay
# OR extract the source zip to this location
```

### Step 2: Set RACK_DIR Environment Variable

**Linux/Mac:**
```bash
export RACK_DIR=/path/to/Rack-SDK
```

**Windows (MSYS2):**
```bash
export RACK_DIR=/c/path/to/Rack-SDK
```

Alternatively, you can edit the Makefile and set `RACK_DIR` directly at the top.

### Step 3: Compile

```bash
cd QuantumDelay
make
```

This will compile the plugin. You should see output like:
```
g++ -c -o build/src/plugin.cpp.o src/plugin.cpp ...
g++ -c -o build/src/QuantumSuperpositionDelay.cpp.o src/QuantumSuperpositionDelay.cpp ...
g++ -o plugin.so ...
```

### Step 4: Install to VCV Rack

**Option A: Install via make**
```bash
make install
```

This copies the plugin to your VCV Rack plugins directory.

**Option B: Manual install**

Copy the entire `QuantumDelay` folder to your VCV Rack plugins directory:

- **Linux**: `~/.Rack2/plugins-v2/`
- **Mac**: `~/Documents/Rack2/plugins-v2/`
- **Windows**: `%USERPROFILE%\Documents\Rack2\plugins-v2\`

### Step 5: Test in VCV Rack

1. Launch VCV Rack
2. Right-click in the rack
3. Search for "Quantum"
4. Add the "Quantum Superposition Delay" module

## Troubleshooting Build Issues

### "RACK_DIR not found"

Make sure you've set the `RACK_DIR` environment variable or edited the Makefile.

### Compiler not found

**Windows**: Make sure you're using the MSYS2 MinGW terminal, not the regular Windows command prompt.

**Mac**: Install Xcode Command Line Tools: `xcode-select --install`

**Linux**: Install build tools: `sudo apt-get install build-essential`

### "undefined reference" errors

This usually means the SDK version doesn't match. Make sure you're using VCV Rack SDK v2.0 or higher.

### Module doesn't appear in VCV Rack

1. Check that the plugin compiled successfully (you should see `plugin.so`, `plugin.dll`, or `plugin.dylib` in the `QuantumDelay` folder)
2. Verify the plugin is in the correct plugins directory
3. Check VCV Rack logs for errors: Help → Show User Folder → `log.txt`

## Development Workflow

### Iterative Development

For rapid iteration during development:

```bash
# In the plugin directory
make clean    # Clean previous build
make          # Rebuild
make install  # Install to Rack

# Or all at once:
make clean && make && make install
```

Then restart VCV Rack to load the updated plugin.

### Debug Build

For debugging with GDB or LLDB:

```bash
make clean
make FLAGS="-g -O0"
```

This creates a debug build with symbols and no optimization.

### Verbose Build

To see full compiler commands:

```bash
make V=1
```

## Customization

### Changing Buffer Count

Edit `src/QuantumSuperpositionDelay.cpp`:

```cpp
static constexpr int NUM_BUFFERS = 6;  // Change to 4, 8, 12, etc.
```

Note: More buffers = more CPU usage and memory

### Changing Maximum Delay Time

```cpp
static constexpr int MAX_DELAY_SAMPLES = 96000;  // 2 sec at 48kHz
// Change to 192000 for 4 seconds, etc.
```

Note: Longer delays = more memory usage

### Adjusting Panel Layout

Edit `src/QuantumSuperpositionDelay.cpp` in the Widget constructor to change knob/jack positions.

Or create a new panel design by editing `res/QuantumSuperpositionDelay.svg` in Inkscape or similar.

## Creating a Distributable Package

To create a .zip for distribution:

```bash
make dist
```

This creates `QuantumDelay-<version>-<platform>.vcvplugin` which can be shared with others.

## File Structure Reference

```
QuantumDelay/
├── Makefile                 # Build configuration
├── plugin.json             # Plugin metadata (name, version, etc.)
├── README.md               # User documentation
├── BUILD.md                # This file
├── LICENSE                 # License file
├── src/
│   ├── plugin.hpp          # Plugin header declarations
│   ├── plugin.cpp          # Plugin initialization
│   └── QuantumSuperpositionDelay.cpp  # Module implementation
├── res/
│   └── QuantumSuperpositionDelay.svg  # Panel artwork
└── build/                  # Compiled object files (created by make)
```

## Next Steps

After successfully building:

1. Read the main README.md for usage instructions
2. Try the example patches
3. Experiment with modifying the code
4. Join the VCV Rack community forum to share your creations!

## Additional Resources

- VCV Rack Plugin Development Tutorial: https://vcvrack.com/manual/PluginDevelopmentTutorial
- VCV Rack API Documentation: https://vcvrack.com/docs-v2/
- VCV Community Forum: https://community.vcvrack.com/

---

Happy patching!
